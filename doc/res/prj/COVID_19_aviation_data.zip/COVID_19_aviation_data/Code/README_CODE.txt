This is a description in running "main.m" which will reproduce the results in the manuscript.

Before running main, you should run "COVID_processing.m" first in "Pre_Processing" folder.

You will output the following:

1. "county_adjacency.csv" which is the county adjacency matrix

2. simulated infected level for urban region and rural region

3. output figures: simulated infected level and real infected level over time. (shown in the paper Section V.)



 

