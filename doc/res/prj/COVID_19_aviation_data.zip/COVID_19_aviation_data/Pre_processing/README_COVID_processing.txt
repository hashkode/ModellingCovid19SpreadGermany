Before running preprocessing download the following:

1. Download “time_series_covid19_confirmed_US.csv” and “time_series_covid19_deaths_US.csv” from
https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data/csse_covid_19_time_series. Save these files to "COVID19_datasets" directory.

2. Download “daily.csv”from
https://api.covidtracking.com/v1/states/daily.csv
Save this file to  "COVID19_datasets"  directory.





 

